<template>
  <div>
    <nuxt />
  </div>
</template>

<style>
* {
  font-family: 'Open Sans', sans-serif;
}
</style>
